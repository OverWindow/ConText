import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const out = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(out, '../..');
const require = createRequire(path.join(root, 'frontend/package.json'));
const { chromium } = require('@playwright/test');
const sharp = require('sharp');
await fs.mkdir(path.join(out, 'png'), { recursive: true });
const logo = 'data:image/png;base64,' + (await fs.readFile(path.join(out, 'brand/context-logo.png'))).toString('base64');
const theme = await fs.readFile(path.join(out, 'palette.css'), 'utf8');
const css = `${theme}

*{box-sizing:border-box}html,body{margin:0;width:1920px;height:1080px;overflow:hidden}
body{font-family:'Apple SD Gothic Neo','Noto Sans KR',sans-serif;color:var(--text);letter-spacing:-1.5px}
.frame{position:relative;width:1920px;height:1080px;background:var(--background);overflow:hidden}
.grid{position:absolute;inset:0;background-image:radial-gradient(var(--grid) 1.5px,transparent 1.5px);background-size:32px 32px;mask-image:linear-gradient(120deg,transparent 28%,#000 100%);opacity:.65}
.wash{position:absolute;width:1120px;height:1120px;right:-420px;top:-440px;background:radial-gradient(circle,var(--primary-soft) 0%,var(--secondary-soft) 42%,transparent 69%)}
.rail{position:absolute;left:112px;right:112px;bottom:70px;display:flex;justify-content:space-between;font-size:22px;letter-spacing:1.4px;color:var(--text-muted)}
.rail:before{content:'';position:absolute;top:-24px;left:0;right:0;height:1px;background:var(--border-soft)}
.eyebrow{font-size:24px;font-weight:700;letter-spacing:4px;color:var(--primary)}
.logo{display:block;object-fit:contain;mix-blend-mode:multiply}
h1{margin:0;font-size:98px;line-height:1.24;letter-spacing:-5px;font-weight:800}
.accent{color:var(--primary)}.sub{font-size:31px;line-height:1.6;color:var(--text-muted);letter-spacing:-.7px}
.hero{position:absolute;left:112px;top:126px}
.hero .logo{width:470px;height:164.5px;margin-left:-5px}
.hero h1{margin-top:65px}.hero .sub{margin-top:32px}
.steps{display:flex;gap:14px;align-items:center;margin-top:62px}
.step{padding:17px 24px;border:1px solid var(--border);border-radius:15px;background:var(--surface);font-size:24px;font-weight:600;color:var(--text-secondary)}
.arrow{color:var(--brand-rose);font-size:26px}
.orbit{position:absolute;right:126px;top:250px;width:565px;height:540px}
.paper{position:absolute;width:218px;height:260px;padding:31px 26px;border:1.5px solid var(--border);border-radius:18px;background:var(--surface);box-shadow:0 22px 65px var(--shadow-color)}
.paper small{font-size:18px;letter-spacing:1px;color:var(--primary);font-weight:700}
.paper b{display:block;font-size:27px;line-height:1.4;margin-top:24px;letter-spacing:-1px}
.lines{margin-top:27px;height:44px;background:repeating-linear-gradient(to bottom,var(--border-soft) 0,var(--border-soft) 5px,transparent 5px,transparent 17px);border-radius:3px}
.paper.one{left:4px;top:6px;transform:rotate(-7deg)}.paper.two{right:2px;top:120px;transform:rotate(7deg)}.paper.three{left:55px;bottom:0;border-color:var(--primary-border)}
.connector{position:absolute;inset:0;width:100%;height:100%}
.problem{position:absolute;top:130px;left:112px}.problem h1{font-size:88px;margin-top:52px}
.questions{display:flex;flex-direction:column;gap:22px;margin-top:45px}
.question{font-size:30px;color:var(--text-secondary);display:flex;gap:20px;align-items:center}
.question i{font-style:normal;font-size:20px;letter-spacing:0;background:var(--primary-soft);color:var(--primary);border-radius:50%;width:40px;height:40px;display:grid;place-items:center}
.problem-right{position:absolute;right:125px;top:185px;width:625px;height:590px}
.file{position:absolute;width:360px;height:154px;padding:26px;border:1px solid var(--border);border-radius:20px;background:var(--surface);box-shadow:0 18px 45px var(--shadow-color)}
.file b{font-size:28px;display:block;letter-spacing:-.6px}.file span{display:block;margin-top:17px;font-size:23px;color:var(--text-muted);letter-spacing:-.4px}
.file.f1{top:0;left:4px;transform:rotate(-8deg)}.file.f2{top:193px;right:0;transform:rotate(7deg)}.file.f3{bottom:0;left:20px;transform:rotate(-4deg)}
.end{position:absolute;top:125px;left:0;width:100%;text-align:center}.end .logo{width:470px;height:164.5px;margin:0 auto}.end h1{font-size:94px;margin-top:50px}.end .sub{margin-top:28px}.end .steps{justify-content:center;margin-top:46px}
.overlay{background:transparent}.lower{position:absolute;left:112px;bottom:150px;display:flex;align-items:center;gap:24px;background:rgba(255,255,255,.97);border:1px solid var(--border);border-radius:18px;padding:25px 34px 25px 25px;box-shadow:0 12px 36px var(--shadow-elevated-color)}
.num{width:68px;height:68px;display:grid;place-items:center;background:var(--primary-soft);border-radius:14px;color:var(--primary);font-size:30px;font-weight:700;letter-spacing:0}
.lower b{font-size:34px;letter-spacing:-1px}.lower p{margin:8px 0 0;font-size:23px;letter-spacing:-.5px;color:var(--text-muted)}
`;
const base = (inner, overlay = false) => `<!doctype html><html lang="ko"><meta charset="utf-8"><style>${css}</style><body><main class="frame ${overlay?'overlay':''}">${overlay?'':'<div class="wash"></div><div class="grid"></div>'}${inner}</main></body></html>`;
const rail = (left, right) => `<div class="rail"><span>${left}</span><span>${right}</span></div>`;
const steps = `<div class="steps"><span class="step">자료 연결</span><span class="arrow">→</span><span class="step">변화 확인</span><span class="arrow">→</span><span class="step">근거 확인</span><span class="arrow">→</span><span class="step">문서 작성</span></div>`;
const scenes = [
 ['01-opening', base(`<section class="hero"><img class="logo" src="${logo}"><h1>문서를 넘어,<br><span class="accent">맥락을 연결하다.</span></h1><p class="sub">문서와 수정 이력, AI 출처를<br>하나의 작업 공간에서.</p>${steps}</section><div class="orbit"><svg class="connector" viewBox="0 0 565 540"><path d="M130 130L440 250L165 420Z" fill="none" stroke="var(--primary-border)" stroke-width="3"/><circle cx="305" cy="190" r="9" fill="var(--secondary)"/><circle cx="310" cy="332" r="9" fill="var(--primary)"/></svg><div class="paper one"><small>DOCUMENT</small><b>팀의 자료</b><div class="lines"></div></div><div class="paper two"><small>HISTORY</small><b>변화의 기록</b><div class="lines"></div></div><div class="paper three"><small>CONTEXT</small><b>연결된 근거</b><div class="lines"></div></div></div>${rail('PRODUCT DEMO','개발 중 · 로컬 실행 시연')}`)],
 ['02-problem', base(`<section class="problem"><div class="eyebrow">WHY CONTEXT</div><h1>문서는 쌓이는데,<br><span class="accent">맥락은 흩어집니다.</span></h1><div class="questions"><div class="question"><i>01</i>어떤 문서가 최신일까?</div><div class="question"><i>02</i>이전 내용에서 무엇이 달라졌을까?</div><div class="question"><i>03</i>어떤 근거로 새 문서를 쓸까?</div></div></section><div class="problem-right"><div class="file f1"><b>제품기획서_v1.docx</b><span>이전 기획은 여기에</span></div><div class="file f2"><b>요금제_확정_회의록.md</b><span>결정의 근거는 여기에</span></div><div class="file f3"><b>출시안내문_최종.pdf</b><span>최종 내용은 또 다른 곳에</span></div></div>${rail('ConText','문제 상황을 설명하는 그래픽')}`)],
 ['03-ending', base(`<section class="end"><img class="logo" src="${logo}"><h1>찾고, 이해하고,<br><span class="accent">다음 문서로.</span></h1><p class="sub">흩어진 자료를 연결해, 근거 있는 결과물로.</p>${steps}</section>${rail('문서의 변화와 맥락을 함께 관리하는 AI 작업 공간','개발 중 · 로컬 실행 시연')}`)],
];
const chapters = [
 ['04-chapter-connect','01','자료를 연결하다','기존 폴더를 하나의 작업 공간으로'],
 ['05-chapter-history','02','변화를 확인하다','수정 이력과 달라진 내용을 함께 확인'],
 ['06-chapter-sources','03','근거를 따라가다','AI 답변에서 인용한 원문까지'],
 ['07-chapter-write','04','다음 문서를 만들다','초안 작성부터 검토와 파일 저장까지'],
];
for (const [name,num,title,desc] of chapters) scenes.push([name,base(`<div class="lower"><div class="num">${num}</div><div><b>${title}</b><p>${desc}</p></div></div>`,true)]);
const browser = await chromium.launch({headless:true});
const page = await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
for (const [name,html] of scenes) {
 await fs.writeFile(path.join(out,`${name}.html`),html);
 await page.setContent(html); await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:path.join(out,'png',`${name}.png`),omitBackground:name.includes('chapter')});
 console.log(`Rendered ${name}`);
}
await browser.close();
const tiles=[];
for(let i=0;i<scenes.length;i++){
 const p=await sharp(path.join(out,'png',`${scenes[i][0]}.png`)).flatten({background:'#F3EFEC'}).resize(640,360).png().toBuffer();
 tiles.push({input:p,left:(i%2)*656+16,top:Math.floor(i/2)*376+16});
}
await sharp({create:{width:1328,height:1520,channels:3,background:'#E8DEDD'}}).composite(tiles).png().toFile(path.join(out,'preview.png'));
